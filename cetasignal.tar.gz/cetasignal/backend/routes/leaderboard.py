"""
routes/leaderboard.py — Score tracking
"""
from fastapi import APIRouter
from routes.game import _sessions

router = APIRouter(tags=["leaderboard"])


@router.get("/leaderboard")
async def get_leaderboard(limit: int = 20):
    """Top scores across all sessions."""
    sessions = list(_sessions.values())
    
    # Calculate accuracy for each session
    for s in sessions:
        s['accuracy'] = round(s['correct'] / s['total'], 3) if s['total'] > 0 else 0
    
    # Sort by total score
    ranked = sorted(sessions, key=lambda x: x['total_score'], reverse=True)[:limit]
    
    return {
        'leaderboard': ranked,
        'total_players': len(sessions)
    }
