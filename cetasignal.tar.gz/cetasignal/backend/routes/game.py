"""
routes/game.py — Game loop endpoints
Handles guess submission, scoring, session tracking
"""
from fastapi import APIRouter, Request
from pydantic import BaseModel
from typing import Optional
from datetime import datetime
import json
from pathlib import Path

router = APIRouter(tags=["game"])

# In-memory store (replace with Supabase/Postgres in production)
_guesses = []
_sessions = {}

SCORE_TABLE = {
    'correct': 100,
    'adjacent': 40,     # e.g., guessed CONTACT but was NAVIGATE — both are coordination
    'wrong': 0
}

# Adjacency map — similar behavioral classes
ADJACENT_CLASSES = {
    'CONTACT':   ['NAVIGATE', 'BROADCAST'],
    'NAVIGATE':  ['CONTACT', 'DIVE'],
    'DIVE':      ['NAVIGATE', 'FORAGE'],
    'FORAGE':    ['DIVE', 'CONTACT'],
    'BROADCAST': ['CONTACT', 'NAVIGATE'],
}


def calculate_score(human_guess: str, ground_truth: str, model_correct: bool) -> dict:
    """Calculate score for a human guess."""
    if human_guess == ground_truth:
        human_correct = True
        human_score = SCORE_TABLE['correct']
        result = 'correct'
    elif human_guess in ADJACENT_CLASSES.get(ground_truth, []):
        human_correct = False
        human_score = SCORE_TABLE['adjacent']
        result = 'adjacent'
    else:
        human_correct = False
        human_score = SCORE_TABLE['wrong']
        result = 'wrong'
    
    # Bonus for beating the model
    beat_model_bonus = 50 if human_correct and not model_correct else 0
    total_score = human_score + beat_model_bonus
    
    return {
        'human_correct': human_correct,
        'result': result,
        'base_score': human_score,
        'beat_model_bonus': beat_model_bonus,
        'total_score': total_score,
        'model_was_correct': model_correct
    }


class GuessSubmission(BaseModel):
    call_id: str
    human_guess: str
    session_id: Optional[str] = None
    player_name: Optional[str] = None
    time_taken_s: Optional[float] = None


@router.post("/guess")
async def submit_guess(submission: GuessSubmission):
    """
    Submit a human guess. Returns:
    - Model prediction (was hidden during guessing)
    - Ground truth
    - Score breakdown
    - Behavioral animation data
    """
    from routes.calls import DEMO_CALLS
    from routes.predict import build_inline_classifier
    
    # Get the call
    call = next((c for c in DEMO_CALLS if c['id'] == submission.call_id), None)
    if not call:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Call not found: {submission.call_id}")
    
    ground_truth_class = call['behavioral_class']
    
    # Run model prediction
    model = build_inline_classifier()
    features = call.get('cadence_features', {})
    model_prediction = model.predict(features)
    model_correct = model_prediction['predicted_class'] == ground_truth_class
    
    # Calculate score
    score_result = calculate_score(submission.human_guess, ground_truth_class, model_correct)
    
    # Build animation data for the behavioral reveal
    animation_data = build_animation_data(call)
    
    # Store guess (anonymized)
    guess_record = {
        'call_id': submission.call_id,
        'human_guess': submission.human_guess,
        'ground_truth': ground_truth_class,
        'model_prediction': model_prediction['predicted_class'],
        'human_correct': score_result['human_correct'],
        'model_correct': model_correct,
        'score': score_result['total_score'],
        'timestamp': datetime.utcnow().isoformat(),
        'time_taken_s': submission.time_taken_s
    }
    _guesses.append(guess_record)
    
    # Update session
    session_id = submission.session_id or 'anonymous'
    if session_id not in _sessions:
        _sessions[session_id] = {
            'player_name': submission.player_name,
            'total_score': 0,
            'correct': 0,
            'total': 0,
            'session_id': session_id
        }
    session = _sessions[session_id]
    session['total_score'] += score_result['total_score']
    session['total'] += 1
    if score_result['human_correct']:
        session['correct'] += 1
    
    return {
        'call_id': submission.call_id,
        'human_guess': submission.human_guess,
        'score': score_result,
        'model_prediction': model_prediction,
        'ground_truth': {
            'class': ground_truth_class,
            'label': call['behavioral_label'],
            'emoji': call['behavioral_emoji'],
            'outcome': call['behavioral_outcome'],
            'species': call['species'],
            'fun_fact': call.get('fun_fact', ''),
            'source': call['source']
        },
        'animation': animation_data,
        'session': session
    }


def build_animation_data(call: dict) -> dict:
    """
    Build data for the behavioral animation shown after reveal.
    Returns timeline of whale positions/depths for animation.
    """
    behavioral_class = call['behavioral_class']
    duration_s = call.get('duration_s', 1.0)
    
    # Generate animation timeline based on behavioral class
    if behavioral_class == 'DIVE':
        return {
            'type': 'dive',
            'keyframes': [
                {'t': 0,    'depth': 0,   'x': 0.5,  'y': 0.1, 'label': 'Call emitted'},
                {'t': 15,   'depth': -10, 'x': 0.5,  'y': 0.2, 'label': 'Descent begins'},
                {'t': 30,   'depth': -40, 'x': 0.48, 'y': 0.5, 'label': 'Dive in progress'},
                {'t': 60,   'depth': -80, 'x': 0.45, 'y': 0.8, 'label': 'Deep dive'},
            ],
            'pod_response': 'Others follow within 30s',
            'depth_max_m': 80,
            'duration_s': 60,
            'color': '#0066CC'
        }
    
    elif behavioral_class == 'CONTACT':
        return {
            'type': 'contact',
            'keyframes': [
                {'t': 0,   'depth': 0, 'x': 0.2,  'y': 0.3, 'label': 'Caller'},
                {'t': 30,  'depth': 0, 'x': 0.3,  'y': 0.3, 'label': 'Responder approaches'},
                {'t': 90,  'depth': 0, 'x': 0.45, 'y': 0.3, 'label': 'Converging'},
                {'t': 180, 'depth': 0, 'x': 0.48, 'y': 0.3, 'label': 'Within 50m'},
            ],
            'second_whale': {
                'keyframes': [
                    {'t': 0,   'x': 0.8,  'y': 0.6},
                    {'t': 30,  'x': 0.7,  'y': 0.5},
                    {'t': 90,  'x': 0.55, 'y': 0.4},
                    {'t': 180, 'x': 0.52, 'y': 0.35},
                ]
            },
            'pod_response': 'Second individual converges within 3 minutes',
            'duration_s': 180,
            'color': '#00D4FF'
        }
    
    elif behavioral_class == 'FORAGE':
        return {
            'type': 'forage',
            'keyframes': [
                {'t': 0,  'depth': 0,   'x': 0.5, 'y': 0.3, 'label': 'Pod together'},
                {'t': 15, 'depth': -5,  'x': 0.5, 'y': 0.3, 'label': 'Spread begins'},
                {'t': 45, 'depth': -15, 'x': 0.3, 'y': 0.2, 'label': 'Arc formation'},
                {'t': 90, 'depth': -20, 'x': 0.2, 'y': 0.2, 'label': 'Foraging spread'},
            ],
            'pod_formation': 'arc',
            'pod_size': 5,
            'spread_m': 250,
            'pod_response': 'Pod spreads into 250m foraging arc',
            'duration_s': 90,
            'color': '#00CC88'
        }
    
    elif behavioral_class == 'NAVIGATE':
        return {
            'type': 'navigate',
            'keyframes': [
                {'t': 0,   'depth': 0, 'x': 0.2, 'y': 0.5, 'heading': 90, 'label': 'Heading established'},
                {'t': 300, 'depth': 0, 'x': 0.4, 'y': 0.5, 'heading': 90, 'label': '5min — heading held'},
                {'t': 900, 'depth': 0, 'x': 0.7, 'y': 0.5, 'heading': 90, 'label': '15min — still on course'},
            ],
            'heading_deg': 90,
            'speed_kmh': 12,
            'pod_response': 'Pod maintains heading for 45 minutes',
            'duration_s': 900,
            'color': '#FF9900'
        }
    
    elif behavioral_class == 'BROADCAST':
        return {
            'type': 'broadcast',
            'keyframes': [
                {'t': 0,    'depth': -20, 'x': 0.5, 'y': 0.5, 'label': 'Song begins'},
                {'t': 600,  'depth': -22, 'x': 0.5, 'y': 0.5, 'label': '10min — stationary'},
                {'t': 1800, 'depth': -18, 'x': 0.51,'y': 0.5, 'label': '30min — still singing'},
                {'t': 2400, 'depth': -20, 'x': 0.5, 'y': 0.5, 'label': '40min — song ends'},
            ],
            'radius_m': 50,
            'signal_range_km': 200,
            'pod_response': 'Caller remains within 200m for entire bout',
            'duration_s': 2400,
            'color': '#CC44FF'
        }
    
    return {'type': 'unknown', 'keyframes': [], 'duration_s': 60}


@router.get("/stats")
async def get_stats():
    """Overall accuracy stats — human vs model vs ground truth."""
    if not _guesses:
        return {
            'total_guesses': 0,
            'human_accuracy': 0,
            'model_accuracy': 0,
            'message': 'No guesses yet — play the game!'
        }
    
    total = len(_guesses)
    human_correct = sum(1 for g in _guesses if g['human_correct'])
    model_correct = sum(1 for g in _guesses if g['model_correct'])
    
    # Per-class breakdown
    class_stats = {}
    for guess in _guesses:
        cls = guess['ground_truth']
        if cls not in class_stats:
            class_stats[cls] = {'total': 0, 'human_correct': 0, 'model_correct': 0}
        class_stats[cls]['total'] += 1
        if guess['human_correct']:
            class_stats[cls]['human_correct'] += 1
        if guess['model_correct']:
            class_stats[cls]['model_correct'] += 1
    
    return {
        'total_guesses': total,
        'human_accuracy': round(human_correct / total, 4),
        'model_accuracy': round(model_correct / total, 4),
        'human_beats_model': human_correct > model_correct,
        'class_breakdown': class_stats,
        'hypothesis_support': model_correct / total > 0.6
    }
