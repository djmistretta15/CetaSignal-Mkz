"""
routes/calls.py — Whale call data endpoints
"""
from fastapi import APIRouter, HTTPException
from pathlib import Path
import json

router = APIRouter(tags=["calls"])

# Load manifest
DATA_DIR = Path(__file__).parent.parent.parent / "data"
MANIFEST_PATH = DATA_DIR / "manifest.json"

# Inline call data — used when manifest file not present (demo mode)
DEMO_CALLS = [
    {
        "id": "narw_upcall_001",
        "species": "North Atlantic Right Whale",
        "species_code": "narw",
        "call_type": "upcall",
        "behavioral_class": "CONTACT",
        "behavioral_label": "Contact",
        "behavioral_emoji": "📡",
        "behavioral_outcome": "Pod convergence — two individuals approached within 50m over 3 minutes",
        "duration_s": 1.2,
        "peak_freq_hz": 170,
        "source": "NOAA NEFSC DCLDE 2013",
        "annotation_confidence": "definite",
        "audio_url": None,
        "is_synthetic": True,
        "description": "Rising frequency sweep from ~100Hz to ~170Hz over 1.2 seconds.",
        "fun_fact": "Right whale upcalls are the most studied whale contact call. They function like a 'here I am' beacon.",
        "difficulty": 1,
        "cadence_features": {
            "peak_freq_hz": 170,
            "freq_contour": "rising",
            "duration_s": 1.2,
            "inter_pulse_interval_ms": 1200,
            "urgency_score": 0.2,
            "repetition_hz": 0.1
        }
    },
    {
        "id": "fin_20hz_001",
        "species": "Fin Whale",
        "species_code": "fin",
        "call_type": "20hz_pulse",
        "behavioral_class": "NAVIGATE",
        "behavioral_label": "Navigate",
        "behavioral_emoji": "🧭",
        "behavioral_outcome": "Sustained directional heading for 45 minutes post-call series",
        "duration_s": 3.4,
        "peak_freq_hz": 20,
        "source": "NOAA NEFSC DCLDE 2013",
        "annotation_confidence": "definite",
        "audio_url": None,
        "is_synthetic": True,
        "description": "Regular 20Hz pulse repeated every ~26 seconds. Extremely low frequency — pitched up 10x for audibility.",
        "fun_fact": "At 20Hz, fin whale calls are below human hearing range. They travel hundreds of miles through the SOFAR channel.",
        "difficulty": 3,
        "cadence_features": {
            "peak_freq_hz": 20,
            "freq_contour": "flat",
            "duration_s": 3.4,
            "inter_pulse_interval_ms": 26000,
            "urgency_score": 0.1,
            "repetition_hz": 0.038
        }
    },
    {
        "id": "humpback_song_001",
        "species": "Humpback Whale",
        "species_code": "humpback",
        "call_type": "song_phrase",
        "behavioral_class": "BROADCAST",
        "behavioral_label": "Broadcast",
        "behavioral_emoji": "📻",
        "behavioral_outcome": "Whale remained stationary during 40-minute song bout",
        "duration_s": 8.1,
        "peak_freq_hz": 400,
        "source": "NOAA SanctSound CI05_05 2020",
        "annotation_confidence": "definite",
        "audio_url": None,
        "is_synthetic": True,
        "description": "Complex repeating phrase with sweeps from 200-800Hz. Rhythmically structured ~8s phrase.",
        "fun_fact": "Humpback songs are the most complex known non-human acoustic sequences — and they change every year.",
        "difficulty": 2,
        "cadence_features": {
            "peak_freq_hz": 400,
            "freq_contour": "complex",
            "duration_s": 8.1,
            "inter_pulse_interval_ms": 300,
            "urgency_score": 0.15,
            "repetition_hz": 0.12
        }
    },
    {
        "id": "orca_burst_pulse_001",
        "species": "Orca (Southern Resident)",
        "species_code": "orca",
        "call_type": "burst_pulse",
        "behavioral_class": "FORAGE",
        "behavioral_label": "Forage",
        "behavioral_emoji": "🐟",
        "behavioral_outcome": "Pod spread into foraging arc — 150-300m spacing within 90 seconds",
        "duration_s": 2.7,
        "peak_freq_hz": 2000,
        "source": "NOAA Pacific Islands DCLDE 2022",
        "annotation_confidence": "definite",
        "audio_url": None,
        "is_synthetic": True,
        "description": "Rapid click bursts at ~2kHz, irregular inter-pulse intervals 5-20ms.",
        "fun_fact": "Orca burst pulses during foraging are pod-specific — different pods have different 'dialects' for hunting.",
        "difficulty": 2,
        "cadence_features": {
            "peak_freq_hz": 2000,
            "freq_contour": "flat",
            "duration_s": 2.7,
            "inter_pulse_interval_ms": 12,
            "urgency_score": 0.75,
            "repetition_hz": 5.2
        }
    },
    {
        "id": "sei_downsweep_001",
        "species": "Sei Whale",
        "species_code": "sei",
        "call_type": "downsweep",
        "behavioral_class": "DIVE",
        "behavioral_label": "Dive",
        "behavioral_emoji": "🌊",
        "behavioral_outcome": "Dive initiated within 15s — depth 0→40m over 30 seconds",
        "duration_s": 0.9,
        "peak_freq_hz": 240,
        "source": "NOAA NEFSC DCLDE 2013",
        "annotation_confidence": "definite",
        "audio_url": None,
        "is_synthetic": True,
        "description": "Sharp descending sweep from ~240Hz to ~80Hz over 0.9 seconds.",
        "fun_fact": "Sei whale downsweeps reliably precede dives. The descending frequency may mimic the sensation of descent.",
        "difficulty": 1,
        "cadence_features": {
            "peak_freq_hz": 240,
            "freq_contour": "descending",
            "duration_s": 0.9,
            "inter_pulse_interval_ms": 900,
            "urgency_score": 0.35,
            "repetition_hz": 0.0
        }
    },
    {
        "id": "blue_ab_call_001",
        "species": "Blue Whale",
        "species_code": "blue",
        "call_type": "ab_call",
        "behavioral_class": "CONTACT",
        "behavioral_label": "Contact",
        "behavioral_emoji": "📡",
        "behavioral_outcome": "Response call received ~50km away 8 minutes later",
        "duration_s": 18.5,
        "peak_freq_hz": 17,
        "source": "NOAA NEFSC DCLDE 2013",
        "annotation_confidence": "definite",
        "audio_url": None,
        "is_synthetic": True,
        "description": "A-call (tonal 17Hz) + B-call (amplitude modulated 17Hz). Pitched up 10x for audibility.",
        "fun_fact": "Blue whale A/B calls are the loudest animal sounds on Earth — up to 188 decibels. They can travel ocean basins.",
        "difficulty": 4,
        "cadence_features": {
            "peak_freq_hz": 17,
            "freq_contour": "flat",
            "duration_s": 18.5,
            "inter_pulse_interval_ms": 18500,
            "urgency_score": 0.1,
            "repetition_hz": 0.05
        }
    },
    {
        "id": "narw_gunshot_001",
        "species": "North Atlantic Right Whale",
        "species_code": "narw",
        "call_type": "gunshot",
        "behavioral_class": "CONTACT",
        "behavioral_label": "Contact",
        "behavioral_emoji": "📡",
        "behavioral_outcome": "Surfacing blow recorded within 20 seconds",
        "duration_s": 0.3,
        "peak_freq_hz": 500,
        "source": "NOAA NEFSC DCLDE 2013",
        "annotation_confidence": "definite",
        "audio_url": None,
        "is_synthetic": True,
        "description": "Broadband impulsive call — rapid wideband burst. Named for acoustic similarity to distant gunshot.",
        "fun_fact": "Right whale gunshot calls may be male advertisement signals. Females sometimes respond by surfacing.",
        "difficulty": 3,
        "cadence_features": {
            "peak_freq_hz": 500,
            "freq_contour": "complex",
            "duration_s": 0.3,
            "inter_pulse_interval_ms": 300,
            "urgency_score": 0.6,
            "repetition_hz": 0.0
        }
    },
    {
        "id": "minke_pulse_train_001",
        "species": "Minke Whale",
        "species_code": "minke",
        "call_type": "pulse_train",
        "behavioral_class": "NAVIGATE",
        "behavioral_label": "Navigate",
        "behavioral_emoji": "🧭",
        "behavioral_outcome": "Consistent heading maintained for 20 minutes",
        "duration_s": 5.2,
        "peak_freq_hz": 1200,
        "source": "NOAA NEFSC DCLDE 2013",
        "annotation_confidence": "possible",
        "audio_url": None,
        "is_synthetic": True,
        "description": "Regular pulse train at ~1200Hz, pulses every 100-400ms. Rhythmically consistent.",
        "fun_fact": "Minke 'Star Wars' calls are so named for their sci-fi sound. They were only attributed to minke whales in 2014.",
        "difficulty": 4,
        "cadence_features": {
            "peak_freq_hz": 1200,
            "freq_contour": "flat",
            "duration_s": 5.2,
            "inter_pulse_interval_ms": 250,
            "urgency_score": 0.2,
            "repetition_hz": 0.8
        }
    }
]

# Guess options presented to users
GUESS_OPTIONS = [
    {"id": "CONTACT",   "label": "Contact",   "emoji": "📡", "description": "I'm here / Where are you?",        "color": "#00D4FF"},
    {"id": "DIVE",      "label": "Dive",       "emoji": "🌊", "description": "Going down — follow me",           "color": "#0066CC"},
    {"id": "FORAGE",    "label": "Forage",     "emoji": "🐟", "description": "Food detected / spread out",       "color": "#00CC88"},
    {"id": "NAVIGATE",  "label": "Navigate",   "emoji": "🧭", "description": "Directional / migration heading",  "color": "#FF9900"},
    {"id": "BROADCAST", "label": "Broadcast",  "emoji": "📻", "description": "Stationary signal / advertisement","color": "#CC44FF"},
]


def get_all_calls():
    """Load calls from manifest or fall back to demo data."""
    if MANIFEST_PATH.exists():
        try:
            with open(MANIFEST_PATH) as f:
                data = json.load(f)
            if data:
                return data
        except:
            pass
    return DEMO_CALLS


@router.get("/calls")
async def list_calls(species: Optional[str] = None, difficulty: Optional[int] = None):
    """List all available whale calls."""
    calls = get_all_calls()
    
    if species:
        calls = [c for c in calls if species.lower() in c.get('species_code', '').lower()]
    
    if difficulty:
        calls = [c for c in calls if c.get('difficulty') == difficulty]
    
    return {
        "calls": calls,
        "total": len(calls),
        "guess_options": GUESS_OPTIONS
    }


@router.get("/calls/random")
async def random_call():
    """Get a random call for the game."""
    import random
    calls = get_all_calls()
    call = random.choice(calls)
    return {"call": call, "guess_options": GUESS_OPTIONS}


@router.get("/calls/{call_id}")
async def get_call(call_id: str):
    """Get a specific call by ID."""
    calls = get_all_calls()
    for call in calls:
        if call['id'] == call_id:
            return {"call": call, "guess_options": GUESS_OPTIONS}
    raise HTTPException(status_code=404, detail=f"Call '{call_id}' not found")


from typing import Optional
