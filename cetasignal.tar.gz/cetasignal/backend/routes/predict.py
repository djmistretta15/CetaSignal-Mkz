"""
routes/predict.py — Model prediction endpoint
"""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from pathlib import Path
import pickle
import sys

router = APIRouter(tags=["predict"])

MODEL_PATH = Path(__file__).parent.parent / "models" / "cadence_classifier.pkl"

# Lazy-loaded model
_model = None

def get_model():
    global _model
    if _model is None:
        if MODEL_PATH.exists():
            try:
                with open(MODEL_PATH, 'rb') as f:
                    _model = pickle.load(f)
                print(f"✓ Model loaded from {MODEL_PATH}")
            except Exception as e:
                print(f"✗ Model load failed: {e} — using inline classifier")
                _model = build_inline_classifier()
        else:
            print("No model file found — using inline rule-based classifier")
            _model = build_inline_classifier()
    return _model


def build_inline_classifier():
    """Build rule-based classifier inline without needing pickle file."""
    class InlineClassifier:
        def predict(self, features: dict) -> dict:
            peak_freq = features.get('peak_freq_hz', 100)
            contour = features.get('freq_contour', 'flat')
            duration = features.get('duration_s', 1.0)
            ipi_ms = features.get('inter_pulse_interval_ms', 500)
            urgency = features.get('urgency_score', 0.3)
            repetition = features.get('repetition_hz', 0)

            # Rule-based scoring
            scores = {'CONTACT': 0.2, 'DIVE': 0.2, 'FORAGE': 0.2, 'NAVIGATE': 0.2, 'BROADCAST': 0.2}
            reasons = []

            # Frequency priors
            if peak_freq < 50:
                scores['NAVIGATE'] += 0.3; scores['CONTACT'] += 0.2
                reasons.append(f"Very low frequency ({peak_freq:.0f}Hz) — long-range navigation signal")
            elif peak_freq < 300:
                scores['CONTACT'] += 0.2; scores['DIVE'] += 0.15
                reasons.append(f"Low-mid frequency ({peak_freq:.0f}Hz)")
            elif peak_freq < 1000:
                scores['BROADCAST'] += 0.25; scores['CONTACT'] += 0.15
            else:
                scores['FORAGE'] += 0.3
                reasons.append(f"High frequency ({peak_freq:.0f}Hz) — foraging/echolocation range")

            # Contour
            if contour == 'descending':
                scores['DIVE'] += 0.35
                reasons.append("Descending sweep → dive initiation")
            elif contour == 'rising':
                scores['CONTACT'] += 0.35
                reasons.append("Rising sweep → contact/upcall pattern")
            elif contour == 'complex':
                scores['BROADCAST'] += 0.3
                reasons.append("Complex contour → structured song/broadcast")

            # Duration
            if duration > 5:
                scores['BROADCAST'] += 0.2; scores['NAVIGATE'] += 0.1
                reasons.append(f"Long duration ({duration:.1f}s) → broadcast signal")
            elif duration < 0.5:
                scores['DIVE'] += 0.15; scores['FORAGE'] += 0.1
                reasons.append(f"Short impulsive ({duration:.2f}s)")

            # IPI
            if ipi_ms < 50:
                scores['FORAGE'] += 0.25
                reasons.append(f"Rapid bursts ({ipi_ms:.0f}ms IPI) → foraging pattern")
            elif ipi_ms > 5000:
                scores['NAVIGATE'] += 0.2
                reasons.append(f"Slow pulse rate ({ipi_ms:.0f}ms) → navigation/migration")

            # Urgency
            if urgency > 0.6:
                scores['FORAGE'] += 0.15
                reasons.append("High urgency pattern")

            # Strong signal overrides
            if contour == 'descending' and duration < 2.0:
                predicted_class = 'DIVE'; confidence = 0.87
            elif contour == 'rising' and peak_freq < 500:
                predicted_class = 'CONTACT'; confidence = 0.82
            elif peak_freq < 30 and duration > 10:
                predicted_class = 'NAVIGATE'; confidence = 0.79
            elif peak_freq > 1500 and ipi_ms < 50:
                predicted_class = 'FORAGE'; confidence = 0.83
            elif contour == 'complex' and duration > 4:
                predicted_class = 'BROADCAST'; confidence = 0.76
            else:
                total = sum(scores.values()) + 1e-8
                probs = {k: v/total for k, v in scores.items()}
                predicted_class = max(probs, key=probs.get)
                confidence = round(probs[predicted_class], 3)

            CLASS_META = {
                'CONTACT':   {'label': 'Contact',   'emoji': '📡', 'description': "I'm here / Where are you?",         'color': '#00D4FF'},
                'DIVE':      {'label': 'Dive',       'emoji': '🌊', 'description': 'Going down — follow me',            'color': '#0066CC'},
                'FORAGE':    {'label': 'Forage',     'emoji': '🐟', 'description': 'Food detected / spread out',        'color': '#00CC88'},
                'NAVIGATE':  {'label': 'Navigate',   'emoji': '🧭', 'description': 'Directional / migration heading',   'color': '#FF9900'},
                'BROADCAST': {'label': 'Broadcast',  'emoji': '📻', 'description': 'Stationary signal / advertisement', 'color': '#CC44FF'},
            }

            total = sum(scores.values()) + 1e-8
            probs = {k: round(v/total, 4) for k, v in scores.items()}

            meta = CLASS_META[predicted_class]
            return {
                'predicted_class': predicted_class,
                'predicted_label': meta['label'],
                'predicted_emoji': meta['emoji'],
                'predicted_description': meta['description'],
                'predicted_color': meta['color'],
                'confidence': confidence,
                'class_probabilities': probs,
                'reasoning': reasons,
                'model_version': 'rule_based_inline_v1'
            }
    return InlineClassifier()


class FeaturesInput(BaseModel):
    peak_freq_hz: float = 100.0
    freq_contour: str = 'flat'
    duration_s: float = 1.0
    inter_pulse_interval_ms: float = 500.0
    urgency_score: float = 0.3
    repetition_hz: float = 0.0
    spectral_bandwidth_hz: Optional[float] = None
    zero_crossing_rate: Optional[float] = None


class CallIdInput(BaseModel):
    call_id: str


@router.post("/predict")
async def predict_from_features(features: FeaturesInput):
    """Run model prediction from cadence features."""
    model = get_model()
    result = model.predict(features.dict())
    return {"prediction": result}


@router.post("/predict/call")
async def predict_for_call(body: CallIdInput):
    """Run model prediction for a specific call by ID."""
    from routes.calls import DEMO_CALLS
    
    call = next((c for c in DEMO_CALLS if c['id'] == body.call_id), None)
    if not call:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail=f"Call '{body.call_id}' not found")
    
    model = get_model()
    features = call.get('cadence_features', {})
    result = model.predict(features)
    
    return {
        "call_id": body.call_id,
        "prediction": result,
        "ground_truth": {
            "class": call['behavioral_class'],
            "label": call['behavioral_label'],
            "emoji": call['behavioral_emoji'],
            "outcome": call['behavioral_outcome']
        }
    }
