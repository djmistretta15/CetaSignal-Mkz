"""
CetaSignal Backend — FastAPI
----------------------------
Endpoints:
  GET  /api/calls              — List all available whale calls
  GET  /api/calls/{call_id}    — Get single call metadata
  POST /api/predict            — Predict behavioral class from features
  POST /api/guess              — Submit human guess, get model prediction + score
  GET  /api/leaderboard        — Top scores
  GET  /api/stats              — Overall accuracy stats (human vs model)
  GET  /health                 — Health check
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path
import json
import pickle
import sys
import os
from datetime import datetime
from typing import Optional

sys.path.append(str(Path(__file__).parent.parent / 'scripts'))

from routes.calls import router as calls_router
from routes.predict import router as predict_router
from routes.game import router as game_router
from routes.leaderboard import router as leaderboard_router

app = FastAPI(
    title="CetaSignal API",
    description="Whale acoustic cadence decoder — human vs. AI vs. ground truth",
    version="1.0.0"
)

# CORS — allow frontend dev server
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://localhost:3000",
        "https://cetasignal.vercel.app",
        "https://*.vercel.app"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount audio files as static
audio_dir = Path(__file__).parent.parent / "data" / "calls"
if audio_dir.exists():
    app.mount("/audio", StaticFiles(directory=str(audio_dir)), name="audio")

# Include routers
app.include_router(calls_router, prefix="/api")
app.include_router(predict_router, prefix="/api")
app.include_router(game_router, prefix="/api")
app.include_router(leaderboard_router, prefix="/api")


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "service": "CetaSignal",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat()
    }


@app.get("/")
async def root():
    return {
        "message": "🐋 CetaSignal API",
        "docs": "/docs",
        "endpoints": {
            "calls": "/api/calls",
            "predict": "/api/predict",
            "guess": "/api/guess",
            "leaderboard": "/api/leaderboard",
            "stats": "/api/stats"
        }
    }
