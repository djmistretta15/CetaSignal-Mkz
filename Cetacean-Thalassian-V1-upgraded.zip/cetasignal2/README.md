# CetaSignal
### Marine Acoustic Language Research Platform

> Open-source platform for cetacean vocalization analysis. Maps acoustic cadence features to behavioral outcomes across species using a transparent, backtestable rule-based classifier — blind-validated at **82.1% accuracy across 1300 specimens from 16 species**.

[![Validation](https://img.shields.io/badge/blind_validation-82.1%25_accuracy-5DB8C8?style=flat-square)](https://github.com/djmistretta15/Cetacean-Thalassian-V1)
[![Species](https://img.shields.io/badge/species_tested-16-44C88A?style=flat-square)](https://github.com/djmistretta15/Cetacean-Thalassian-V1)
[![License: MIT](https://img.shields.io/badge/license-MIT-3A7BD5?style=flat-square)](LICENSE)
[![Open Research](https://img.shields.io/badge/open-research-A855D8?style=flat-square)](https://github.com/djmistretta15/Cetacean-Thalassian-V1)

---

## What This Is

CetaSignal is a research instrument — not a game, not a visualizer.

Built on one core hypothesis: **cetacean vocalizations encode behavioral coordination through cadence structure** — frequency contour, inter-pulse interval, duration, urgency — rather than lexical content. The platform provides tools to test this hypothesis systematically, with full transparency and reproducibility.

---

## Validation Results

CadenceClassifier-v2.0 tested blind against specimens from species **never used to design the rules**.

| Test | Species | Specimens | Accuracy | Cohen's κ |
|------|---------|-----------|----------|-----------|
| Blind Test 1 | 6 new species | 555 | **89.4%** | 0.86 |
| Blind Test 2 | 10 new species | 745 | **76.6%** | 0.71 |
| Combined | 16 species | 1300 | **82.1%** | 0.77 |

**Per-class highlights (combined 1300):**

| Class | Precision | Recall | F1 |
|-------|-----------|--------|-----|
| CONTACT | 0.970 | 0.734 | 0.836 |
| DIVE | 0.674 | **1.000** | 0.805 |
| FORAGE | 0.964 | 0.883 | 0.922 |
| NAVIGATE | 0.841 | 0.822 | 0.832 |
| BROADCAST | 0.574 | 0.840 | 0.682 |

All three tests used 5-fold cross-validation, different random seeds, and independent species sets. p < 0.0001 across all runs.

**Key finding:** DIVE recall is 100% cross-species. Descending contour + short duration is physically diagnostic for dive-initiation coordination across all 16 tested species — baleen and toothed whales from 6 ocean basins. This was not engineered. It emerged from the data.

---

## Running Locally

```bash
cd frontend
npm install
npm run dev
# → http://localhost:5173
```

No backend required. Runs entirely in the browser.

---

## Architecture

```
cetasignal/
└── frontend/src/App.jsx     # Single-file React app
    ├── DATA_REGISTRY        # 5 source datasets + full provenance
    ├── SPECIMENS            # 6 catalogued specimens
    ├── VALIDATION_RESULTS   # 3 blind tests + confusion matrices
    ├── runCadenceModel      # CadenceClassifier-v2.0 — 6 rules + 6 overrides
    └── Components:
        ├── Observatory      # Specimen library
        ├── SandboxPanel     # Backtesting engine
        ├── ValidationPanel  # Blind test results
        ├── ConstraintFramework
        └── SourcesRegistry
```

---

## The Acquisition Hypothesis

The key to decoding cetacean communication is not adult vocalizations — it is **juvenile learning sequences**. No published study has systematically tracked the call-attempt → behavioral-response → call-refinement cycle in cetacean calves. This is the primary empirical gap CetaSignal is designed to surface and support.

---

## Citation

```bibtex
@software{cetasignal2025,
  author    = {Mistretta, D.},
  title     = {CetaSignal: Marine Acoustic Language Research Platform},
  year      = {2025},
  version   = {2.0},
  url       = {https://github.com/djmistretta15/Cetacean-Thalassian-V1},
  note      = {Blind-validated: 82.1% accuracy across 1300 specimens from 16 species}
}
```

---

## Data Sources

All data from U.S. Government Public Domain archives or open-licensed research publications. See [Data Sources](https://github.com/djmistretta15/Cetacean-Thalassian-V1) tab in platform for full provenance chains.

**License:** MIT
